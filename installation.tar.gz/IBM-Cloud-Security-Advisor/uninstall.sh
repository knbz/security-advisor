#!/bin/bash

clear

printf "IBM Cloud Security Advisor Uninstaller\n"
printf "======================================\n\n"

###### Uninstall prerequisites ######
#####################################

# Check for the OS type and set node executable accordingly.
osType=$(uname)
if [ "$osType" = "Linux" ]
then
  # Running on a Linux variant.
  decode="base64 -d"
else
  # Running on macOS.
  decode="base64 -D"
fi

printf "Checking prerequisites...\r"

# Don't run if IBM Cloud CLI updates are available.
checkForCLIUpdate=$(ibmcloud update | grep "No update required")
if [ "$checkForCLIUpdate" != "No update required. Your CLI is already up-to-date." ]
then
  printf "\n\nUnable to start: Incompatible IBM Cloud CLI version (minimum required: v0.6.5).\nRun 'ibmcloud update' to update.\n\n"
  exit
fi

printf "Checking prerequisites   \n"

###### Verify connectivity ######
#################################

printf "Verifying connectivity...\r"

# Don't run if not connceted to IBM Cloud.
ibmcloudStatus=$(ibmcloud account list | head -n 1)
if [ "$ibmcloudStatus" = "FAILED" ]
then
  printf "\n\nUnable to start: Not connected to IBM Cloud.\nRun 'ibmcloud login' to connect.\n\nReview the README.md file for installation instructions.\n\n"
  exit
fi

# Don't run if not connected to a Kubernetes cluster.
if [ -z "$KUBECONFIG" ]
then
  printf "\n\nUnable to start: Not connected to a Kubernetes cluster.\nRun 'ibmcloud ks clusters' followed by 'ibmcloud ks cluster-config <cluster name/id>'.\n\nReview the README.md file for installation instructions.\n\n"
  exit
else
  # Don't run if Tiller not installed
  isTillerExist=$(kubectl get pods -n kube-system | grep "tiller")
  if [ -z "$isTillerExist" ]
  then
    printf "\n\nUnable to start: Helm server component not installed.\nRun 'helm init'.\n\nReview the README.md file for installation instructions.\n\n"
    exit
  fi
fi

# Verify the connected cluster belongs to the connected IBM Cloud account.
kubectl get cm cluster-info -n kube-system -o json | jq .data."\"cluster-config.json"\" | jq -r . > temp.json
cluster_id=$(cat temp.json | jq .cluster_id | tr -d '"')
clusterInfo=$(ibmcloud ks cluster-get $cluster_id)

isValidAccountCluster=$(echo "$clusterInfo" | grep "FAILED")
if [ "$isValidAccountCluster" = "FAILED" ]
then
  printf "\n\nUnable to start: Cluster does not belong to this IBM Cloud account.\nVerify you've connected to the correct account and cluster.\n\n"
  exit
fi

printf "Verifying connectivity   \n"
printf "Removing Security Advisor components...\r"

###### Remove Cards Configuration ######
########################################

# Obtain cluster meatadata: Datacenter, Cluster ID, and Account ID to generate cluster CRN.
kubectl get cm cluster-info -n kube-system -o json | jq .data."\"cluster-config.json"\" | jq -r . > temp.json

cluster_id=$(cat temp.json | jq .cluster_id | tr -d '"')
account_id=$(cat temp.json | jq .account_id | tr -d '"')
datacenter=$(cat temp.json | jq .datacenter | tr -d '"')
clusterCrn="crn:v1:bluemix:public:containers-kubernetes:$datacenter:a%2f$account_id:$cluster_id::"

apiKey=$(kubectl get secrets security-advisor-secrets -n monitoring -o json | jq .data.iamConfig | tr -d '"' | $decode | jq .externalService.apiKey | tr -d '"')
if [ -z "$apiKey" ]; then
  printf "API Key not present (security-advisor-secrets already removed) .\n"
else
  access_token=$(curl -X POST -H "Accept: application/json" -H "Content-Type: application/x-www-form-urlencoded" -s -d "grant_type=urn%3Aibm%3Aparams%3Aoauth%3Agrant-type%3Aapikey&apikey=$apiKey&response_type=cloud_iam" https://iam.ng.bluemix.net/oidc/token | jq .access_token | tr -d '"')
  curl -X DELETE "https://us-south-ingest.secadvisor.cloud.ibm.com/api/v1/securityrawdata/cluster/$clusterCrn" -s -H "accept: application/json" -H "Authorization: Bearer $access_token" -H "Content-Type: application/json" &> /dev/null
  printf "Cards configuration removed .\n\n"
fi


###### Purge Security Advisor components ######
###############################################

helm del --purge security-advisor &> /dev/null

printf "Removing Security Advisor components   \n\n"

###### Clean IBM Cloud account ######
#####################################

serviceName=$(ibmcloud iam service-ids | grep "SecurityAdvisorAccessService" | awk '{print $2}')

ibmcloud iam service-id-delete $serviceName -f &> /dev/null

if [ $? -eq 0 ]; then
    printf "Service id $serviceName deleted successfully. \n\n"
else
    printf "Error while deleting Service id or Service name does not exists. \n\n"
fi

# Restore resources folder
rm -rf subnet.json temp.json cluster_info.json
if [ -d "config/resources-backup/" ]; then
  rm -rf config/resources/
  mv config/resources-backup/ config/resources/
  printf "Restored the resources folder .\n\n"
fi

printf "Uninstall completed successfully\n\n"
