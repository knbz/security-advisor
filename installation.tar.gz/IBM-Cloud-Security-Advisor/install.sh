#!/bin/bash

clear

printf "IBM Cloud Security Advisor Installer\n"
printf "====================================\n\n"

###### Setup & Helpers ######
#############################

# Backup the resources folder.
cp -r config/resources config/resources-backup

# Utility function to restore resources folder and exit program.
function restoreAndExit() {
  printf "\n\nInstaller aborted!\n\n"
  rm -rf subnet.json temp.json cluster_info.json
  rm -rf config/resources/
  mv config/resources-backup/ config/resources/
  exit
}

# Catch ctrl-c.
trap 'restoreAndExit' INT

# Check for the OS type and set node executable accordingly.
osType=$(uname)
if [ "$osType" = "Linux" ]
then
  # Running on a Linux variant.
  nodeExec=nodejs
  encode="base64 -w 0"
else
  # Running on macOS.
  nodeExec=node
  encode="base64"
fi

###### Installer prerequisites ######
#####################################

printf "Checking prerequisites...\r"

# Don't run if any of the prerequisites are not installed.
prerequisites=( "jq" "$nodeExec" "bx" "kubectl" "helm" )
for i in "${prerequisites[@]}"
do
  isExist=$(command -v $i)
  if [ -z "$isExist" ]
  then
    prereqStatus="false"
    errorLine="* $i not installed."
    missingReqs+=("$errorLine")
  fi
done

isCSPluginInstalled=$(bx plugin list | grep "container-service" | awk '{print $1}')
if [ -z "$isCSPluginInstalled" ]
then
  prereqStatus="false"
  errorLine="* container-service plug-in not installed."
  missingReqs+=("$errorLine")
fi

# Print out which prerequisites are missing and exit the program.
if [ "$prereqStatus" = "false" ]
then
  printf "Unable to start: Prerequisites not met.\n"
  printf "%s\n" "${missingReqs[@]}"
  printf "\nReview the README.md file for installation instructions.\n\n"
  restoreAndExit
fi

# Don't run if IBM Cloud CLI updates are available.
checkForCLIUpdate=$(bx update | grep "No update required")
if [ "$checkForCLIUpdate" != "No update required. Your CLI is already up-to-date." ]
then
  printf "\n\nUnable to start: Incompatible IBM Cloud CLI version (minimum required: v0.6.5).\nRun 'bx update' to update.\n\n"
  restoreAndExit
fi

# Don't run if container-service plug-in has available updates.
checkForPluginUpdate=$(bx plugin repo-plugins -r Bluemix | grep "container-service" | grep "Update Available")
if ! [ -z "$checkForPluginUpdate" ]
then
  printf "\n\nUnable to start: Outdated container-service plug-in.\nRun 'bx plugin update' to update.\n\n"
  restoreAndExit
fi

printf "Checking prerequisites   \n"

###### Verify connectivity ######
#################################

printf "Verifying connectivity...\r"

# Don't run if not connceted to IBM Cloud.
bxStatus=$(bx account list | head -n 1)
if [ "$bxStatus" = "FAILED" ]
then
  printf "\n\nUnable to start: Not connected to IBM Cloud.\nRun 'bx login' to connect.\n\nReview the README.md file for installation instructions.\n\n"
  restoreAndExit
fi

# Don't run if not connected to a Kubernetes cluster.
if [ -z "$KUBECONFIG" ]
then
  printf "\n\nUnable to start: Not connected to a Kubernetes cluster.\nRun 'bx cs clusters' followed by 'bx cs cluster-config <cluster name/id>'.\n\nReview the README.md file for installation instructions.\n\n"
  restoreAndExit
else
  # Don't run if Tiller not installed
  isTillerExist=$(kubectl get pods -n kube-system | grep "tiller")
  if [ -z "$isTillerExist" ]
  then
    printf "\n\nUnable to start: Helm server component not installed.\nRun 'helm init'.\n\nReview the README.md file for installation instructions.\n\n"
    restoreAndExit
  fi
fi

printf "Verifying connectivity   \n"

###### Collect metadata ######
##############################

printf "Collecting metadata...\r"

# Obtain cluster meatadata: Datacenter, Cluster ID, and Account ID to generate cluster CRN.
kubectl get cm cluster-info -n kube-system -o json | jq .data."\"cluster-config.json"\" | jq -r . > temp.json

# Store the cluster ID, account ID and Data Center seperately, to be used later on.
cluster_id=$(cat temp.json | jq .cluster_id | tr -d '"')
account_id=$(cat temp.json | jq .account_id | tr -d '"')
datacenter=$(cat temp.json | jq .datacenter | tr -d '"')

# Obtain cluster name and plan.
clusterInfo=$(bx cs cluster-get $cluster_id)
clusterName=$(echo "$clusterInfo" | grep "Name:" | awk '{print $2}')
clusterPlan=$(echo "$clusterInfo" | grep "Ingress Subdomain" | awk '{print $3}')

# Verify the connected cluster belongs to the connected IBM Cloud account.
isValidAccountCluster=$(echo "$clusterInfo" | grep "FAILED")
if [ "$isValidAccountCluster" = "FAILED" ]
then
  printf "\n\nUnble to collect metadata: Cluster does not belong to this IBM Cloud account.\nVerify you've connected to the correct account and cluster.\n\n"
  restoreAndExit
fi

# Check if the cluster is Lite or Paid.
if [ "$clusterPlan" = "-" ]
then
  # This is a Lite cluster, set default values.
  cat temp.json | jq '. += {"cluster_external_url": " "}' > cluster_info.json
  cat cluster_info.json | jq '. += {"ingress_ip": " "}' > temp.json
  cat temp.json | jq '. += {"subnet": " "}' > cluster_info.json
  cat cluster_info.json | jq '. += {"logmet_endpoint": " "}' > temp.json
  cat temp.json | jq '. += {"logmet_token": " "}' > cluster_info.json
  cat cluster_info.json | jq '. += {"space_id": " "}' > temp.json
else
  # This is a Paid cluster, gather the needed metadata.

  # Obtain Ingress subdomain URL.
  cluster_external_url=$(echo "$clusterInfo" | grep "Ingress Subdomain" | awk '{print $3}')
  cat temp.json | jq --arg ingressUrl "$cluster_external_url" '. += {"cluster_external_url": $ingressUrl}' > cluster_info.json

  # Obtain Ingress subdomain IP address.
  ingress_ip=$(kubectl get cm -n kube-system -o json ibm-cloud-provider-vlan-ip-config | jq .data.reserved_public_ip | tr -d '"')
  cat cluster_info.json | jq --arg ingressIp "$ingress_ip" '. += {"ingress_ip": $ingressIp}' > temp.json

  # Obtain cluster public subnet.
  kubectl get cm -n kube-system -o json ibm-cloud-provider-vlan-ip-config > subnet.json
  isTrue=$(cat subnet.json | jq .data."\"vlanipmap.json"\" | jq -r . | jq .vlans[0].subnets[].is_public)

  if [ $isTrue = "true" ]
  then
    subnet=$(cat subnet.json | jq .data."\"vlanipmap.json"\" | jq -r . | jq .vlans[0].subnets[].cidr | tr -d '"')
  else
    subnet=$(cat subnet.json | jq .data."\"vlanipmap.json"\" | jq -r . | jq .vlans[1].subnets[].cidr | tr -d '"')
  fi
  cat temp.json | jq --arg publicSubnet "$subnet" '. += {"subnet": $publicSubnet}' > cluster_info.json

  # Obtain Log Analysis endpoint, space ID and token.
  verifyLogmetEnabled=$(bx cs logging-config-get $cluster_id --logsource container --json | tail -n 1)
  if ! [ "$verifyLogmetEnabled" = "[]" ]
  then
    # Endpoint.
    logmet_endpoint=$(bx cs logging-config-get $cluster_id --logsource container --json | tail -n +2 | jq '.remoteLogServer' | tr -d '"')
    cat cluster_info.json | jq --arg logAnalysisEndpoint "$logmet_endpoint" '. += {"logmet_endpoint": $logAnalysisEndpoint}' > temp.json

    # Space ID.
    space_id=$(bx cs logging-config-get $cluster_id --logsource container --json | tail -n +2 | jq '.spaceGUID' | tr -d '"')
    cat temp.json | jq --arg logAnalysisSpaceGuid "$space_id" '. += {"space_id": $logAnalysisSpaceGuid}' > cluster_info.json

    # Token.
    tokenInBase64Decoded=$(kubectl get secret logmet-secrets -n kube-system -o json | jq .data."\"$logmet_endpoint"\" | tr -d '"' | $encode --decode)
    logmet_token=$(echo $tokenInBase64Decoded | jq -r . | jq ."\"$space_id"\" | jq -r . | jq .token | tr -d '"')
    logmetTokenEncoded=$(printf $logmet_token | $encode)
    cat cluster_info.json | jq --arg logmetToken "$logmetTokenEncoded" '. += {"logmet_token": $logmetToken}' > temp.json
  else
    cat cluster_info.json | jq '. += {"logmet_endpoint": " "}' > temp.json
    cat temp.json | jq '. += {"logmet_token": " "}' > cluster_info.json
    cat cluster_info.json | jq '. += {"space_id": " "}' > temp.json
  fi
fi

# Obtain worker nodes' public IPs.
cluster_vms=$(bx cs workers $cluster_id --json | jq -c '.[].publicIP' | tr -d '"' | tr '\n' ' ')
cat temp.json | jq --arg publicIps "$cluster_vms" '. += {"cluster_vms": $publicIps}' > cluster_info.json

printf "Collecting metadata   \n"

###### Prepare Kubernetes resources ######
##########################################

printf "Preparing Kubernetes resources...\r"

# Prepare DataGateway ConfigMap.
$nodeExec config/mustacher config/resources/templates/datagateway-configmap.yaml cluster_info.json

# Special case for SkyDive, requires cluster VMs IP addresses with /32 ending.
cluster_vms_skydive=$(bx cs workers $cluster_id --json | jq -c '.[].publicIP' | tr -d '"' | awk '{print $0 "/32"}' | tr '\n' ' ')
cat cluster_info.json | jq --arg publicIps "$cluster_vms_skydive" '. += {"cluster_vms": $publicIps}' > temp.json
$nodeExec config/mustacher config/resources/skydive.yaml temp.json

# Generate Logmet and IAM Secerts.
# Create accountCRN.
accountCrn="crn:v1:bluemix:public:::a/$account_id:::"

# Get user IAM token.
iam_token=$(bx iam oauth-tokens | head -n 1 | awk '{print $4}')

if [ -z "$iam_token" ]; then
  printf "Unble to get the IAM TOKEN .\n"
  restoreAndExit
else
  printf "IAM TOKEN retrieved successfully .\n"
fi

# Create ServiceId.
serviceCrn=$(curl -X POST -H "Authorization: Bearer $iam_token" -H "Content-Type: application/json" -s -d '{"name": "SecurityAdvisorAccessService-'"$clusterName"'", "description": "Service ID for accessing IBM Cloud Security Advisor", "boundTo": "'"$accountCrn"'"}'  https://iam.bluemix.net/serviceids | jq '.metadata.crn' |tr -d '"')
serviceId="${serviceCrn##*:}"

service_id_exists=$(bx iam service-ids | grep $serviceId)

if [ -z "$service_id_exists" ]; then
  printf "Service ID not generated .\n"
  restoreAndExit
else
  printf "Service ID generated successfully .\n"
fi

# Assign policies.
assignPolicy=$(curl -X POST -H "Authorization: Bearer $iam_token" -H "Content-Type: application/json" -s -d '{ "roles": [{  "id": "crn:v1:bluemix:public:iam::::serviceRole:Writer"}], "resources": [ {  "serviceName": "securityadvisor", "resourceType": "cluster", "resource": "'"$cluster_id"'" }]}' https://iam.bluemix.net/acms/v1/scopes/a%2F$account_id/service_ids/iam-$serviceId/policies)
policyAssigned=$(echo $assignPolicy | grep 'errors')

if [ ! -z "$policyAssigned" ]; then
  printf "Access policy not assigned .\n"
  restoreAndExit
else
  printf "Access policy assigned successfully .\n"
fi

# Create API key.
apiKeyJson=$(curl -X POST -H "Authorization: Bearer $iam_token" -H "Content-Type: application/json" -s -d '{"boundTo": "'"$serviceCrn"'", "name": "SecurityAdvisorAccessService_ApiKey-'"$clusterName"'", "description": "API key of Service ID for accessing IBM Cloud Security Advisor"}' https://iam.bluemix.net/apikeys )
apiKey=$(echo "$apiKeyJson" | jq '.entity.apiKey' |tr -d '"')
apiKeyID=$(echo "$apiKeyJson" | jq '.metadata.uuid' |tr -d '"')

apikey_id_exists=$(bx iam service-api-keys SecurityAdvisorAccessService-$clusterName | grep $apiKeyID)

if [ -z "$apikey_id_exists" ]; then
  printf "API Key not generated .\n"
  restoreAndExit
else
  printf "API Key generated successfully.\n"
fi

# Create iamConfig Secret
iam_config=$(echo '{"serviceCname": "staging", "viewerService": { "serviceid": "ServiceId", "serviceName": "viewer" }, "internalService": { "serviceid": "ServiceId", "serviceName": "internal" }, "adminService": { "serviceid": "ServiceId", "serviceName": "dev" }, "externalService": { "serviceid": "'"$serviceId"'", "serviceName": "SecurityAdvisorAccessService", "apiKey": "'"$apiKey"'" }}' | $encode)
cat temp.json | jq --arg iam_config "$iam_config" '. += {"iam_config": $iam_config}' > cluster_info.json

$nodeExec config/mustacher config/resources/templates/secrets.yaml cluster_info.json

###### Configure cards ######
#############################

# Create ClusterCrn
clusterCrn="crn:v1:bluemix:public:containers-kubernetes:$datacenter:a%2f$account_id:$cluster_id::"

# Get access token from apiKey
access_token=$(curl -X POST -H "Accept: application/json" -H "Content-Type: application/x-www-form-urlencoded" -d "grant_type=urn%3Aibm%3Aparams%3Aoauth%3Agrant-type%3Aapikey&apikey=$apiKey&response_type=cloud_iam" -s https://iam.ng.bluemix.net/oidc/token | jq .access_token | tr -d '"')

# Send configuration request
cardConfig=$(curl -X PUT "https://security-advisor.us-south.bluemix.net/api/v1/securityrawdata/cluster/$clusterCrn" -s -H "accept: application/json" -H "Authorization: Bearer $access_token" -H "Content-Type: application/json" -d "{}")
assigned=$(echo $cardConfig | grep 'Forbidden')

if [ ! -z "$assigned" ]; then
  printf "Cards not configured .\n"
  restoreAndExit
else
  printf "Cards configuration successfully .\n"
fi

printf "Preparing Kubernetes resources   \n"

###### Deploy to cluster ######
###############################

# Create a monitoring namespace.
kubectl create namespace monitoring

if [ $? -gt 0 ]; then
  printf "\nWarning : Monitoring namespace already exists, proceeding with existing monitoring namespace .\n\n"
fi

# Copy the IBM Cloud Container Registry secret to the "monitoring" namespace.
kubectl get secret bluemix-default-secret -o yaml | sed 's/default/monitoring/g' | kubectl -n monitoring create -f - &> /dev/null

printf "Deploying IBM Cloud Security Advisor components...\n\n"
sleep 2.5

# Deploy Kubernetes resources to customer cluster (Services, ConfigMaps, Deployments and Secrets).
helm upgrade security-advisor config/resources --install --namespace monitoring -f config/resources/skydive.yaml

# Remove generated files.
rm -rf subnet.json temp.json cluster_info.json

isInstallSuccessful=$(helm list | grep "security-advisor")
if [[ "$isInstallSuccessful" = *"security-advisor"* ]]
then
  printf "Install completed successfully\n\n"
else
  printf "Unable to verify installation.\nAttempt running the installer again or review the Troubleshooting section in the README.md\n\n"
fi
