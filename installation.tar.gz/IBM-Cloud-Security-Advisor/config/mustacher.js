var fs = require('fs');
var mustache = require('mustache');
var path = require('path');

function createYaml(destFile, sourceFiles){
    //load json sources
    var sources = combineSources(sourceFiles);

    // make path absolute
    destFile = path.isAbsolute(destFile) ? destFile : path.join(process.cwd(), destFile);
    // load, template, and save manifest
    var manifestAsString = fs.readFileSync(destFile, 'utf8');
    var manifest = mustache.render(manifestAsString, sources);
    //create the manifest.yml file
    destFile = destFile.replace(".template","");
    fs.writeFileSync(destFile, manifest);
}

function combineSources(files){
    var sources = {};
    files.forEach(function(sourcePath,index){
        sourcePath = path.isAbsolute(sourcePath) ? sourcePath : path.join(process.cwd(), sourcePath);
        sources = mergeObjects(sources,JSON.parse(fs.readFileSync(sourcePath,'utf8')));
    });
    return sources;
}

function mergeObjects(obj1, obj2){
    var output = {};
    for (var attrname in obj1) { output[attrname] = obj1[attrname]; }
    for (var attrname in obj2) { output[attrname] = obj2[attrname]; }
    return output;
}

createYaml(process.argv[2], process.argv.slice(3));
